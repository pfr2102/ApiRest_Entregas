//FIC: route add many persons for web/pwa
router.post('/many-pwa', personsController.addManyPersonsPWA);